/*
    ======= PORT AND PIN ASSIGNMENTS =======
    RA1      - Analog input for LM35 temperature sensor
    RB0      - Digital input for soil moisture sensor (input only)
    RC2      - PWM output to control servo motor (vent)
    RC6      - Digital output for Ultrasonic Trigger (HC-SR04 Trig)
    RC7      - Digital input for Ultrasonic Echo (HC-SR04 Echo)
    RD0      - Digital output to control Water Pump (via relay/transistor)
    RD1      - Digital output for Fan or temperature indicator LED (fan logic)
    RD2      - Digital output for Ultrasonic �distance detected� LED
    Other pins - Unused, available for expansion
*/

/*
    ======= FUNCTIONAL OVERVIEW =======                                                          cc
    - Soil Moisture: If soil is dry (sensor on RB0 reads HIGH), water pump (RD0) turns ON.
    - Temperature: Reads temp sensor (LM35 on RA1), if >25�C, activates fan (RD1) and opens vent (servo on RC2).
    - Servo (vent): Opens or closes vent based on temperature.
    - Ultrasonic: Measures distance. If an object is detected >=10 cm away, LED on RD2 turns ON.
*/

// === Variable Declarations ===
float voltage;                   // For temp sensor voltage
float temperature_Celsius;       // For calculated temperature value
unsigned int myreadingtemp;      // Raw ADC value for temperature
unsigned char j, k;              // Loop variables for delays
unsigned long T1counts;          // Ultrasonic timer counts
unsigned long T1time;            // Ultrasonic pulse width
unsigned long Distance;          // Calculated distance in cm
int test_moisture;               // Result from soil moisture check
unsigned long loop_counter = 0;

// === Function Prototypes ===
void Delay_ms(void);
void pwm_init(void);
void set_servo_position1(int degrees);
void ATD_init(void);
unsigned int ATD_read(unsigned char port);
void init_sonar(void);
void read_sonar(void);
int moisture(void);
unsigned int Dcntr = 0;   // Timer0 interrupt counter
unsigned int T1overflow = 0;  // Used in TMR1 overflow interrupt (if needed)
unsigned char sonar_trigger_flag = 0;
unsigned int timeout = 0;
void Delay_us(unsigned int us);

void interrupt (void) {
    if (INTCON & 0x04) {
        TMR0 = 225;
        Dcntr++;

        if (Dcntr >= 500) {
            Dcntr = 0;
            sonar_trigger_flag = 1;
        }

        INTCON &= 0xFB;  // Clear TMR0IF
    }

    // Clear any other unnecessary interrupt flags
    PIR1 &= ~(0x05);  // Clear CCP1IF and TMR1IF
}


// === Delay function for general use ===
void Delay_ms(void){
   for(j=0; j<255; j++){
       for(k=0; k<200; k++);
   }
}


// === PWM setup for servo motor on RC2 ===
void pwm_init() {
    // Set RC2 (CCP1) as output for PWM
    TRISC = TRISC & 0xFB; // 0b11111011: RC2=0(output), rest unchanged
    CCP1CON = 0x0C;       // PWM mode on CCP1 (RC2)
    T2CON = T2CON | 0x07; // Timer2 ON, prescaler
    PR2 = 249;            // For ~50Hz (servo pulse)
}

// === Set servo position (vent) by degree on RC2 ===
void set_servo_position1(int degrees) {
    // Converts degrees to pulse width for typical servo (adjust as needed)
    int pulse_width = (degrees + 90) * 8 + 500; // from -90 to +90 degrees
    CCPR1L = pulse_width >> 2;
    CCP1CON = (CCP1CON & 0xCF) | ((pulse_width & 0x03) << 4);
    Delay_ms(200); // Allow servo to reach position
}

// === Analog-to-Digital setup for temp sensor ===
void ATD_init(void){
      ADCON0=0x41;           // Turn on ADC, select channel 0, Fosc/16
      ADCON1=0xC0;           // RA0/RA1 analog, rest digital
}

// === Read analog value from specified port ===
unsigned int ATD_read(unsigned char port) {
     ADCON0 = (ADCON0 & 0xC7) | (port << 3);
     Delay_ms(100);
     ADCON0 = ADCON0 | 0x04;
     while(ADCON0 & 0x04);
     return ((ADRESH << 8) | ADRESL);
}

// === Read soil moisture from RB0 (input only) ===
int moisture() {
    // RB0 reads HIGH if soil is dry, LOW if moist
    if (PORTB & 0x01) {
        // Soil is dry
        return 1;
    } else {
        // Soil is moist
        return 0;
    }
}

// === Ultrasonic sensor functions (RC6=Trig, RC7=Echo) ===

// Triggers ultrasonic and measures distance
void read_sonar(void) {
    timeout = 0;

    T1counts = 0;
    T1time = 0;
    Distance = 0;

    TMR1H = 0;
    TMR1L = 0;

    // Trigger pulse (10�s)
    PORTC |= 0b01000000;   // RC6 HIGH
    Delay_us(10);        // Prefer microsecond precision
    PORTC &= ~0b01000000;  // RC6 LOW

    // Wait for Echo to go HIGH (RC7) with timeout
    timeout = 0;
    while (!(PORTC & 0b10000000)) {
        if (++timeout > 8000) return;  // ~80ms timeout, object too close or not present
    }

    T1CON = 0x11;  // Timer1 ON, prescaler 2, Fosc/4

    // Wait for Echo to go LOW (end of echo pulse)
    timeout = 0;
    while (PORTC & 0b10000000) {
        if (++timeout > 30000) break;  // ~300ms timeout
    }

    T1CON = 0x10;  // Timer1 OFF

    T1counts = ((TMR1H << 8) | TMR1L);
    T1time = T1counts;

   Distance = (T1time * 0.034) / 2;  // Convert to cm

    if (Distance > 400) {
        Distance = 0;  // Out of range
    }
}
// Initializes ultrasonic timer variables
void init_sonar(void) {
    T1counts = 0;
    T1time = 0;
    Distance = 0;
    TMR1H = 0;
    TMR1L = 0;
    T1CON = 0x18;    // Timer1 OFF initially
}

// === MAIN FUNCTION ===

void main(){
    // === PORT/PIN SETUP ===
   OPTION_REG = 0x07;  // Prescaler 1:256 (adjust as needed)
   TMR0 = 225;         // Preload for ~1ms
   INTCON = 0xA0;      // Enable Timer0 interrupt and global interrupts
    // PWM/Servo on RC2 (output), Ultrasonic Trig on RC6 (output), Echo on RC7 (input)
    pwm_init();
    TRISC = (TRISC & 0x39) | 0b10000000; // RC2 output, RC6 output, RC7 input (0b10000000)

    // Temperature sensor analog input on RA1, rest digital
    ADCON1 = 0x06;      // RA0/RA1 analog, rest digital
    TRISA = 0x03;       // RA0, RA1 as input (others output)

    // Soil Moisture sensor input on RB0 only, rest outputs
    TRISB = 0x01;       // RB0 input, RB1-7 output (but we only use RB0 for input)
    PORTB = 0x00;

    // Outputs: RD0 (water pump), RD1 (fan), RD2 (ultrasonic LED), RD3 for the buzzer
    TRISD = TRISD & 0xF0;   // RD0 to RD3 as output (bits 0�3 cleared)

    PORTD = 0x00;

    ATD_init();
    init_sonar();

    while (1) {
        // === TEMPERATURE & FAN/SERVO LOGIC ===
        myreadingtemp = ATD_read(1);  // Read from RA1 (temp sensor)
        Delay_ms(1000);                // 1 second delay between readings

        voltage = (myreadingtemp / 1023.0) * 500;        // Calculate voltage (5V ADC)
        temperature_Celsius = voltage;            // LM35: 10mV/�C

        if(temperature_Celsius >= 30){
            PORTD = PORTD | 0x02;    // Set RD1 HIGH: Fan ON
        } else {
            PORTD = PORTD & (~0x02); // Set RD1 LOW: Fan OFF
        }

        // === SOIL MOISTURE & WATER PUMP LOGIC ===
        test_moisture = moisture();      // Read soil state on RB0
        if(test_moisture == 1){
            PORTD = PORTD | 0x01;       // Set RD0 HIGH: Pump ON
        } else {
            PORTD = PORTD & (~0x01);    // Set RD0 LOW: Pump OFF
        }

          // === Sonar Trigger from Interrupt ===
    if (sonar_trigger_flag) {
        sonar_trigger_flag = 0;   // Clear flag
        read_sonar();             // Read sonar safely
    }                   // Trigger and read ultrasonic
       // === DISTANCE REACTION LOGIC ===
       if (Distance > 0 && Distance <= 8) {
       PORTD &= ~(0x0C);  // RD2 and RD3 OFF
    } else if (Distance > 8 && Distance <= 13){
        PORTD |= 0x04;     // RD2 and RD3 ON
    } else if(Distance > 13) {
      PORTD |= 0x0C;
    }



        // === 5-MINUTE SERVO TIMER LOGIC ===
        loop_counter++;
        if (loop_counter >= 250) { // 250 * 1200ms = 300,000ms = 5 minutes
        set_servo_position1(90);   // Rotate to 90 degrees
        Delay_ms(10000);            // Hold for 10 seconds
        set_servo_position1(-90);  // Return to original position
        loop_counter = 0;          // Reset counter
        }

        Delay_ms(100);                   // Short general delay
    }
}


void Delay_us(unsigned int us){
     int i;
     for(i = 1; i < us; i++){
           asm nop;
           asm nop;
     }
}